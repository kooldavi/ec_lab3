/*
 * HMI.h
 *
 * Created: 10.08.2011 15:24:57
 *  Author: operator
 */ 


#ifndef HMI_H_
#define HMI_H_

// 
extern void  vIO_SRAM_to_LCD ( void * pvParameters);
// 
extern void  vTaster ( void * pvParameters);
// 
extern void vHMI (void * pvParameters);

#endif /* HMI_H_ */