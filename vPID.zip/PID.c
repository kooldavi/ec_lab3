/*
 * PID.c
 *
 * Created: 10.08.1921 12:40:11
 *  Author: Henry Ford
 */ 
// Compiler includes
#include <math.h>
#include <avr/io.h>
// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
// Module includes
#include "global.h"
#include "PID.h"
//----------------------------------------------------------
void  vPID ( void * pvParameters) {
	float x = 0.0, y = 0.0;
	float p_error = 0.0;
	float i_error = 0.0;
	float d_error = 0.0;
	float lastError = 0.0;
	float sampleTime = 0.018;

	for (;;) {
		xQueueReceive (QueueSensor, &x, portMAX_DELAY);
		//p=0.190
		//i=0.018
		//d=0.510
		p_error = reference - x;
		i_error += p_error;
		d_error = p_error - lastError;
		lastError = p_error;		

		y = (proportional * p_error) + (integral * i_error * sampleTime) + (derivative * d_error / sampleTime);

		xQueueSend (QueueServo, &y, portMAX_DELAY);
	}
}